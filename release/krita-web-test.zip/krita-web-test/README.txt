Krita in the browser: test build
================================

Try it on your own computer
  1. Install Node.js (any recent version).
  2. In this folder run:   node serve.mjs . 8080
  3. Open http://localhost:8080/krita/ in Chrome or Edge.

Put it on your Cloudflare site
  See deploy/README.md. In short:
    deploy/upload.sh . <your-r2-bucket> --remote
  uploads the krita/ folder (large files are brotli-compressed first), and
  deploy/cloudflare-worker.js serves /krita/* from the bucket with the headers the engine needs.
  It can be mounted inside the Worker that already serves your site; the README shows how.

What to expect
  First load is about 53 MB (compressed); after that the browser caches it.
  Start-up takes roughly 6 seconds on a desktop.
  The page must be served with cross-origin isolation headers (serve.mjs and the Worker both send them);
  opening index.html straight from disk will not work.
  Phones and tablets get a touch layout automatically. Add ?ui=desktop, ?ui=tablet or ?ui=phone to force one.
  Add ?engineLog=1 to see the engine's debug log in the browser console.

Known limits are listed in docs/pass6/STATUS.md in the repository.
